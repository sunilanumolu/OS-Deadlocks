#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char *argv[])
{
	if (argc <= 1)
	{
		printf(1, "please provide one string\n");
		exit();
	}

	int c;
	for (int m = 1; m < argc; m++)
	{
		c = 0;
		while (argv[m][c] != '\0')
		{
			if (argv[m][c] >= 'A' && argv[m][c] <= 'Z')
				argv[m][c] = argv[m][c] + 32;
			else if (argv[m][c] >= 'a' && argv[m][c] <= 'z')
				argv[m][c] = argv[m][c] - 32;
			c++;
		}
	}

	for (int k = 1; k < argc; k++)
		printf(1, "%s ", argv[k]);

	printf(1, "\n");
	exit();
}